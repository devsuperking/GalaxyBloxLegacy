document.getElementById("GalaxyBloxDiscordLink").addEventListener('click', () => {
    chrome.tabs.create({url: "https://discord.gg/thujbtSHC7"})
});
document.getElementById("MicroplayTwitter").addEventListener('click', () => {
    chrome.tabs.create({url: "https://twitter.com/MicroplayStudio"})
});
document.getElementById("MicroplayYouTube").addEventListener('click', () => {
    chrome.tabs.create({url: "https://www.youtube.com/channel/UCddf456Nk9vZuVPhtQOCrSg"})
});
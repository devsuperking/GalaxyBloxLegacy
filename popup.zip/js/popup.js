var key = 'Not loaded...'

document.getElementById("showTokenButton").addEventListener("click", function() {
    if (document.getElementById("token").textContent.startsWith("*")) {
        // Klucz jest niewidzialny
        document.getElementById("token").textContent = key;
        document.getElementById("showTokenButton").textContent = "Hide"
    } else {
        document.getElementById("token").textContent = "*******************************"
        document.getElementById("showTokenButton").textContent = "Show"
    }
})

document.getElementById("MicroplayDiscordLink").addEventListener('click', () => {
    chrome.tabs.create({url: "https://discord.gg/yQhsNkqnDP"})
});
document.getElementById("MicrobloxDiscordLink").addEventListener('click', () => {
    chrome.tabs.create({url: "https://discord.gg/thujbtSHC7"})
});
document.getElementById("MicroplayTwitter").addEventListener('click', () => {
    chrome.tabs.create({url: "https://twitter.com/MicroplayStudio"})
});
document.getElementById("MicroplayYouTube").addEventListener('click', () => {
    chrome.tabs.create({url: "https://www.youtube.com/channel/UCddf456Nk9vZuVPhtQOCrSg"})
});

document.getElementById("activateButton").addEventListener("click", function() {
    const token = document.getElementById("keyInput").value;
    chrome.storage.local.set({"key": token})
    document.getElementsByClassName("ProductNotActivated")[0].style.display = "none";
    document.getElementsByClassName("ProductActivated")[0].style.display = "flex";
})

chrome.storage.local.get(["key"]).then((e) => {
    key = e["key"];
    console.log(key);
    if (key != undefined && key != null) {
        document.getElementsByClassName("ProductNotActivated")[0].style.display = "none";
        document.getElementsByClassName("ProductActivated")[0].style.display = "flex";
    }
});